#!/bin/bash

if [ ! -e /run/shm/host-zk ]; then
  echo 'Creating /run/shm/host-zk & restarting zookeeper'
  sudo mkdir -p /run/shm/host-zk
  sudo chown -R zookeeper: /run/shm/host-zk
  sudo service zookeeper restart
fi
mkdir -p /run/shm/scion-zk/zk1-12-2
mkdir -p /run/shm/scion-zk/zk1-12-1
mkdir -p /run/shm/scion-zk/zk1-12-3
